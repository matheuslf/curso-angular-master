
export interface IFormCanDeactivate {

    podeDesativar();
}