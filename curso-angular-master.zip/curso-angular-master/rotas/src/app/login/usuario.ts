
export class Usuario {

    nome: string;
    senha: string;
}