export const ptbrLocale = settingsService => settingsService.getLocale();
