export const environment = {
  production: true,
  API: '/',
  BASE_URL: ''
};
